exports.handler = function (event, context) {
	context.succeed('hello world');
};